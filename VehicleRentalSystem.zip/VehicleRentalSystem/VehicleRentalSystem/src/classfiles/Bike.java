package classfiles;

public class Bike extends Vehicle {
    public float CalcRate(float rate, int hour) {
        return rate * hour;
    }
}
